How to launch CW?
1.unzip .zip file (probably you have done this step)
2.double click the .pyc file
3.Enjoy!
============================
Check out the url below for latest version and data!
https://github.com/ACE0PERFECT/CameraWorkshop
