How to launch CW?
1.unzip .zip file (probably you have done this step)
2.launch a terminal in current folder and use ./CameraWorkshop.py
3.Enjoy!
============================
Check out the url below for latest version and data!
https://github.com/ACE0PERFECT/CameraWorkshop
