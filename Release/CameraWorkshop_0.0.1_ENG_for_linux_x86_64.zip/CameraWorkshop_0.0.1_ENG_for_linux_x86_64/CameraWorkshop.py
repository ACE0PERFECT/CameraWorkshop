import CameraWorkshop


CameraWorkshop.WhichOS()
CameraWorkshop.Start()